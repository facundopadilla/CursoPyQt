def mostrarNombre():
	print("Mi nombre es Facundo :)")

class Sumar():

	def __init__(self):
		print("Se inició la clase Sumar()")