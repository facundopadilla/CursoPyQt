from setuptools import setup
setup(
    name="facundo",
    version="0.1",
    description="Paquete de ejemplo",
    author="Facundo Padilla",
    packages=['facundo'],
    scripts=[]
)